#include "mainwindow.h"

int n;
int i=1;
void function (int j)
{
switch (i)
{

case 1:
MainWindow::players[1]->nextlocation(j);
i=2;
    break;

case 2 :
players[2]->nextlocation(j);
if(n>=3)
i=3;
else
i=1;
    break;

case 3 :
players[3]->nextlocation(j);
if(n>=4)
i=4;
else
i=1;
    break;


case 4 :
players[4]->nextlocation(j);
if(n>=5)
i=5;
else
i=1;
    break;

case 5 :
players[5]->nextlocation(j);
if(n>=6)
i=6;
else
i=1;
    break;

case 6 :
players[6]->nextlocation(j);
if(n>=7)
i=7;
else
i=1;
    break;

case 7 :
players[7]->nextlocation(j);
if(n>=8)
i=8;
else
i=1;
    break;

case 8 :
players[8]->nextlocation(j);
i=1;
    break;

}

}
