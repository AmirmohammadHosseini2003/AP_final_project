#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QLabel>
#include <QPixmap>

    player players1(1);
    player players2(2);
    player players3(3);
    player players4(4);
    player players5(5);
    player players6(6);
    player players7(7);
    player players8(8);




int * player::nextlocation(int n)
{


    static int abc[3];

    int lastlocation = location;
    location = lastlocation + n;
    if (location > 39 )
        location = location - 40;
    int a= color;
    int b= lastlocation;
    int c=location;



    abc[0]=a;
    abc[1]=b;
    abc[2]=c;

return abc;

}




MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

//    for (int i=1;i<=320;i++)
//  {
//      auto lbl = findChild<QLabel*>("label"+QString::number(i));
//      lbl->hide();

// }
    ui->game_board->hide();
    ui->players_property_label->hide();
    ui->tass_pushbutton->hide();




}





void MainWindow:: showlocation1(int a,int b,int c)
{


    //int num= 8(b-1) + a;
   // auto lbl =  findChild<QLabel>("label"+QString::number(num));
   // lbl->hide();

  //  num= 8(c-1) + a;
  //  qDebug() << num ;
  //  lbl = findChild<QLabel>("label"+QString::number(num));
  //  lbl->show();

qDebug()<<a;
qDebug()<<b;
qDebug()<<c;

    auto lbl =  findChild<QLabel*>("labelp"+QString::number(a));
    //lbl->move (150,700);

    switch (c)
    {
    case '1':

        {
        auto lbl =  findChild<QLabel*>("labelp"+QString::number(a));
        lbl->move (970,900);
         }
        break;

    case '2': {
    auto lbl =  findChild<QLabel*>("labelp"+QString::number(a));
      lbl->move (840,900);
    }
      break;

    case '3': {
       auto lbl =  findChild<QLabel*>("labelp"+QString::number(a));
       lbl->move (740,900);
      }
        break;
//    case '4':
//       // lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//      //  lbl->move (650,900);
//          break;
//    case '5':
//       // lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//      //  lbl->move (560,900);
//          break;
//    case '6':
//        //lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        //lbl->move (490,900);
//          break;
//    case '7':
//      //  lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//       // lbl->move (430,900);
//          break;
//    case '8':
//       // lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//       // lbl->move (370,900);
//          break;
//    case '9':
//       // lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//      //  lbl->move (300,900);
//          break;
//    case '10':
//        //lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//       // lbl->move (210,900);
//          break;
//    case '11':
//      //  lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//       // lbl->move (110,900);
//          break;
//    case '12':
//       // lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        //lbl->move (140,840);
//          break;
//    case '13':
//       // lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//     //   lbl->move (140,760);
//          break;
//    case '14':
//      //  lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//      //  lbl->move (140,670);
//          break;
//    case '15':
//       // lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (140,590);
//          break;
//    case '16':
//       // lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (140,510);
//          break;
//    case '17':
//      //  lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (140,430);
//          break;
//    case '18':
//      //  lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (140,360);
//          break;
//    case '19':
//      //  lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (140,270);
//          break;
//    case '20':
//       // lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (140,180);
//          break;
//    case '21':
//        //lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (140,120);
//          break;
//    case '22':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (220,120);
//          break;
//    case '23':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (310,120);
//          break;
//    case '24':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (370,120);
//          break;
//    case '25':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (430,120);
//          break;
//    case '26':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (500,120);
//          break;
//    case '27':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (560,120);
//          break;
//    case '28':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (650,120);
//          break;
//    case '29':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (750,100);
//          break;
//    case '30':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (850,90);
//          break;
//    case '31':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (930,120);
//          break;
//    case '32':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (930,180);
//          break;
//    case '33':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (930,270);
//          break;
//    case '34':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (920,360);
//          break;
//    case '35':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (930,420);
//          break;
//    case '36':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (920,500);
//          break;
//    case '37':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (920,590);
//          break;
//    case '38':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (920,670);
//          break;
//    case '39':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (920,740);
//          break;
//    case '40':
//        lbl =  findChild<QLabel*>("labelp"+QString::number(a));
//        lbl->move (930,840);
//          break;

    }
}


MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_start_pushbutton_clicked()
{


    ui->numbers_question_label->hide();
    ui->start_pushbutton->hide();
    ui->comboBox->hide();
    ui->welcome_label->hide();
    ui->game_board->show();
    ui->players_property_label->show();
    ui->tass_pushbutton->show();
    int n = 2 + ui->comboBox->currentIndex();

//    for (int i = n ; i < 9; i++ )
//    {
//        switch i //amiiiiiiiiiiiir

//    }
}





int i=1;
int* function (int j, int n)
{
static int * abc ;
switch (i)
{

case 1:
 abc = players1.nextlocation(j);

i=2;
    break;

case 2 :
abc = players2.nextlocation(j);
if(n>=3)
i=3;
else
i=1;
    break;

case 3 :
abc = players3.nextlocation(j);
if(n>=4)
i=4;
else
i=1;
    break;


case 4 :
abc = players4.nextlocation(j);
if(n>=5)
i=5;
else
i=1;
    break;

case 5 :
abc = players5.nextlocation(j);
if(n>=6)
i=6;
else
i=1;
    break;

case 6 :
abc = players6.nextlocation(j);
if(n>=7)
i=7;
else
i=1;
    break;

case 7 :
abc = players7.nextlocation(j);
if(n>=8)
i=8;
else
i=1;
    break;

case 8 :
abc = players8.nextlocation(j);
i=1;
    break;

}

return abc;
}


void MainWindow::on_tass_pushbutton_clicked()
{

    srand(time(0));
    int tass_1 = rand()%6+1;
    int tass_2 = rand()%6+1;
    ui->tasstext1->setText(QString::number(tass_1));
    ui->tasstext2->setText(QString::number(tass_2));
    int tass_sum = tass_1 + tass_2;
    int x = ui->comboBox->currentIndex();
    int *abc = function(tass_sum, x+2);
    showlocation1(*(abc +0),*(abc +1),*(abc +2));
//ui->labelp3->move(490,900);
//ui->labelp5->move(490,700);

    QPixmap tass1(":/images/tass1.png");
    QPixmap tass2(":/images/tass2.png");
    QPixmap tass3(":/images/tass3.png");
    QPixmap tass4(":/images/tass4.png");
    QPixmap tass5(":/images/tass5.png");
    QPixmap tass6(":/images/tass6.png");


    switch (tass_1)
    {

    case 1:
        ui->tasstext1->setPixmap(tass1);
        break;
    case 2:

        ui->tasstext1->setPixmap(tass2);
        break;
    case 3:

        ui->tasstext1->setPixmap(tass3);
        break;
    case 4:

        ui->tasstext1->setPixmap(tass4);
        break;
    case 5:

        ui->tasstext1->setPixmap(tass5);
        break;
    case 6:

        ui->tasstext1->setPixmap(tass6);
        break;

    }

    switch (tass_2) {

    case 1:
        ui->tasstext2->setPixmap(tass1);
        break;
    case 2:

        ui->tasstext2->setPixmap(tass2);
        break;
    case 3:

        ui->tasstext2->setPixmap(tass3);
        break;
    case 4:

        ui->tasstext2->setPixmap(tass4);
        break;
    case 5:

        ui->tasstext2->setPixmap(tass5);
        break;
    case 6:

        ui->tasstext2->setPixmap(tass6);
        break;

    }



    for (int i=1;i<=ui->comboBox->currentIndex()+2;i++)
    {
        ui->players_property_label->append("player "+QString::number(i)+" :");
        ui->players_property_label->append("finance : ");
        ui->players_property_label->append("cards :");
        ui->players_property_label->append("number of houses : ");
        ui->players_property_label->append("number of hotels : ");


    }


}




void MainWindow::on_pushButton_clicked()
{
    switch (ui->choose_color_combobox->currentIndex())
    {
    case 0:
        setStyleSheet("background-color:blue;");
        break;
    case 1:
        setStyleSheet("background-color:green;");
        break;
    case 2:
        setStyleSheet("background-color:red;");
        break;
    case 3:
        setStyleSheet("background-color:yellow;");
        break;
    case 4:
        setStyleSheet("background-color:orange;");
        break;
    }
}

//QPixmap chance1(":/images/chance1.png");
//QPixmap chance2(":/images/chance2.png");
//QPixmap chance3(":/images/chance3.png");
//QPixmap chance4(":/images/chance4.png");
//QPixmap chance5(":/images/chance5.png");
//QPixmap chance6(":/images/chance6.png");
//QPixmap chance7(":/images/chance7.png");
//QPixmap chance8(":/images/chance8.png");
//QPixmap chance9(":/images/chance9.png");
//QPixmap chance10(":/images/chance10.png");
//QPixmap chance11(":/images/chance11.png");
//QPixmap chance12(":/images/chance12.png");
//QPixmap chance13(":/images/chance13.png");
//QPixmap chance14(":/images/chance14.png");
//QPixmap chance15(":/images/chance15.png");
//QPixmap chance16(":/images/chance16.png");


//class chance
//{
//void function(int a)
//{
//    switch (i)
//    {
//    case '1' :
//        //function
//        //go to 0
//        //show
//        ui->chance_label->setPixmap(chance1);
//    break;

//    case '2' :
//        //function
//        //go to 39
//        //show
//        ui->chance_label->setPixmap(chance2);
//    break;

//    case '3' :
//        //function
//        //go to 25
//        //show
//        ui->chance_label->setPixmap(chance3);
//    break;
//    case '4' :
//        //function
//        //go to 12
//        //show
//        ui->chance_label->setPixmap(chance4);
//    break;
//    case '5' :
//        //function
//        //go to 6
//        //show
//        ui->chance_label->setPixmap(chance5);
//    break;
//    case '6' :
//        //function
//        //go to nearest railroad (rent is 2X)
//        //show
//        ui->chance_label->setPixmap(chance6);
//    break;
//    case '7' :
//        //function
//        //go to nearest ulity
//        //show
//        ui->chance_label->setPixmap(chance7);
//    break;
//    case '8' :
//        //function
//        gotox(getlocation - 3);
//        //show
//        ui->chance_label->setPixmap(chance8);
//    break;
//    case '9' :
//        //function
//        player[a]->increase_finance(50);
//        //show
//        ui->chance_label->setPixmap(chance9);
//    break;
//    case '10' :
//        //function
//        player[a]->increase_finance(150);
//        //show
//        ui->chance_label->setPixmap(chance10);
//    break;
//    case '11' :
//        //function
//        player->decrease_finance(15);
//        //show
//        ui->chance_label->setPixmap(chance11);
//    break;

//    case '12' :
//        //function
//        //n=number of players
//        for (int i=1;i<=n;i++)
//            player[i]->increase_finance(50);
//        player[a]->decrease_finance(n*50);
//        //show
//        ui->chance_label->setPixmap(chance12);
//    break;
//    case '13' :
//        //function
//        player[a]->decrease_finance((house_number*25)+(hotel_number*100));
//        //show
//        ui->chance_label->setPixmap(chance13);
//    break;
//    case '14' :
//        //function
//        gotojail();
//        //show
//        ui->chance_label->setPixmap(chance14);
//    break;
//    case '15' :
//        //function
//        //get out of the jail card
//        //show
//        ui->chance_label->setPixmap(chance15);
//    break;
//    case '16' :
//        //function
//        //go to nearest railroad (rent is 2X)
//        //show
//        ui->chance_label->setPixmap(chance16);
//    break;
//    }






//}




//QPixmap community1(":/images/community1.png");
//QPixmap community2(":/images/community2.png");
//QPixmap community3(":/images/community3.png");
//QPixmap community4(":/images/community4.png");
//QPixmap community5(":/images/community5.png");
//QPixmap community6(":/images/community6.png");
//QPixmap community7(":/images/community7.png");
//QPixmap community8(":/images/community8.png");
//QPixmap community9(":/images/community9.png");
//QPixmap community10(":/images/community10.png");
//QPixmap community11(":/images/community11.png");
//QPixmap community12(":/images/community12.png");
//QPixmap community13(":/images/community13.png");
//QPixmap community14(":/images/community14.png");
//QPixmap community15(":/images/community15.png");
//QPixmap community16(":/images/community16.png");



//class chest
//{
//void function(int a)
//{
//    switch (i)
//    {
//    case '1' :
//        //function
//        //go to 0
//        //show
//        ui->chest_label->setPixmap(community1);
//    break;

//    case '2' :
//        //function
//        player[a]->increase_finance(100);
//        //show
//        ui->chest_label->setPixmap(community2);
//    break;

//    case '3' :
//        //function
//        player[a]->increase_finance(10);
//        //show
//        ui->chest_label->setPixmap(community3);
//    break;
//    case '4' :
//        //function
//        player[a]->increase_finance(200);
//        //show
//        ui->chest_label->setPixmap(community4);
//    break;
//    case '5' :
//        //function
//        player[a]->increase_finance(45);
//        //show
//        ui->chest_label->setPixmap(community5);
//    break;
//    case '6' :
//        //function
//        player[a]->increase_finance(20);
//        //show
//        ui->chest_label->setPixmap(community6);
//    break;
//    case '7' :
//        //function
//        player[a]->increase_finance(25);
//        //show
//        ui->chest_label->setPixmap(community7);
//    break;
//    case '8' :
//        //function
//        player[a]->increase_finance(100);
//        //show
//        ui->chest_label->setPixmap(community8);
//    break;
//    case '9' :
//        //function
//        player[a]->increase_finance(100);
//        //show
//        ui->chest_label->setPixmap(community9);
//    break;
//    case '10' :
//        //function
//        //n = number of players
//        for (int i=1;i<=n;i++)
//            player[i]->decrease_finance(50);
//        player[a]->increase_finance(n*50);
//        //show
//        ui->chest_label->setPixmap(community10);
//    break;
//    case '11' :
//        //function
//        player->decrease_finance(50);
//        //show
//        ui->chest_label->setPixmap(community11);
//    break;

//    case '12' :
//        //function
//        //n=number of players
//        player->decrease_finance(100);
//        //show
//        ui->chest_label->setPixmap(community12);
//    break;
//    case '13' :
//        //function
//        player[a]->decrease_finance(150);
//        //show
//        ui->chest_label->setPixmap(community13);
//    break;
//    case '14' :
//        //function
//        player[a]->decrease_finance((house_number*40)+(hotel_number*115));
//        //show
//        ui->chest_label->setPixmap(community14);
//    break;
//    case '15' :
//        //function
//        gotojail();
//        //show
//        ui->chest_label->setPixmap(community15);
//    break;
//    case '16' :
//        //function
//        //get out of the jail card
//        //show
//        ui->chest_label->setPixmap(community16);
//    break;
//    }




//}

//};
