#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QLabel>
#include <QString>
#include <QTextStream>
#include <QFile>
#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
      Ui::MainWindow *ui;
      void showlocation1(int,int,int);


public slots :
   // void function(int j , int n);



private slots:

    void on_start_pushbutton_clicked();
    void on_tass_pushbutton_clicked();


    void on_pushButton_clicked();

private:

};

class player
{

public:
player(int c)
{
      color=c;
      location=1;
};

void  sendText( int a,int b,int c);


int color;
int location ;
int * nextlocation(int);


};


//connect( players1, SIGNAL( sendText (int a, int b, int c) ), MainWindow::ui, SLOT( void showlocation(int a,int b, int c ) ) );



#endif // MAINWINDOW_H
